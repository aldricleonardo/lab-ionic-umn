// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebase: {
    apiKey: "AIzaSyCKy9cSebUSCdGAHetp1N7Mez_DBGWEXL0",
    authDomain: "umn-ionic-backend-6fed1.firebaseapp.com",
    databaseURL: "https://umn-ionic-backend-6fed1.firebaseio.com",
    projectId: "umn-ionic-backend-6fed1",
    storageBucket: "umn-ionic-backend-6fed1.appspot.com",
    messagingSenderId: "572919122907",
    appId: "1:572919122907:web:14e072ff3cecefe4e075fe",
    measurementId: "G-2R2XMQNP66"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
